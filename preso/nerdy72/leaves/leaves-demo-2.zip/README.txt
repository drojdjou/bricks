com.everydayflash.pv3d.leaf.LeafDemo

Use this class as document class in Flash IDE

or

Set it to 'Always compile' if using FlashDevelop